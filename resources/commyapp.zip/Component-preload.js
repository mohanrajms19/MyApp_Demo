//@ui5-bundle com/myapp/Component-preload.js
sap.ui.require.preload({
	"com/myapp/Component.js":function(){
sap.ui.define(["sap/ui/core/UIComponent","sap/ui/Device","com/myapp/model/models"],function(e,t,i){"use strict";return e.extend("com.myapp.Component",{metadata:{manifest:"json"},init:function(){e.prototype.init.apply(this,arguments);this.getRouter().initialize();this.setModel(i.createDeviceModel(),"device")}})});
},
	"com/myapp/controller/App.controller.js":function(){
sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("com.myapp.controller.App",{onInit(){}})});
},
	"com/myapp/controller/View.controller.js":function(){
sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("com.myapp.controller.View",{onInit:function(){}})});
},
	"com/myapp/i18n/i18n.properties":'# This is the resource bundle for com.myapp\n\n#Texts for manifest.json\n\n#XTIT: Application name\nappTitle=My App \n\n#YDES: Application description\nappDescription=A Fiori application.\n#XTIT: Main view title\ntitle=My App ',
	"com/myapp/manifest.json":'{"_version":"1.58.0","sap.app":{"id":"com.myapp","type":"application","i18n":"i18n/i18n.properties","applicationVersion":{"version":"0.0.1"},"title":"{{appTitle}}","description":"{{appDescription}}","resources":"resources.json","sourceTemplate":{"id":"@sap/generator-fiori:basic","version":"1.11.2","toolsId":"b67a02d4-eed1-404b-8c17-f1f9971993c2"}},"sap.ui":{"technology":"UI5","icons":{"icon":"","favIcon":"","phone":"","phone@2":"","tablet":"","tablet@2":""},"deviceTypes":{"desktop":true,"tablet":true,"phone":true}},"sap.ui5":{"flexEnabled":true,"dependencies":{"minUI5Version":"1.119.1","libs":{"sap.m":{},"sap.ui.core":{},"sap.f":{},"sap.suite.ui.generic.template":{},"sap.ui.comp":{},"sap.ui.generic.app":{},"sap.ui.table":{},"sap.ushell":{}}},"contentDensities":{"compact":true,"cozy":true},"models":{"i18n":{"type":"sap.ui.model.resource.ResourceModel","settings":{"bundleName":"com.myapp.i18n.i18n"}}},"resources":{"css":[{"uri":"css/style.css"}]},"routing":{"config":{"routerClass":"sap.m.routing.Router","viewType":"XML","async":true,"viewPath":"com.myapp.view","controlAggregation":"pages","controlId":"app","clearControlAggregation":false},"routes":[{"name":"RouteView","pattern":":?query:","target":["TargetView"]}],"targets":{"TargetView":{"viewType":"XML","transition":"slide","clearControlAggregation":false,"viewId":"View","viewName":"View"}}},"rootView":{"viewName":"com.myapp.view.App","type":"XML","async":true,"id":"App"}}}',
	"com/myapp/model/models.js":function(){
sap.ui.define(["sap/ui/model/json/JSONModel","sap/ui/Device"],function(e,n){"use strict";return{createDeviceModel:function(){var i=new e(n);i.setDefaultBindingMode("OneWay");return i}}});
},
	"com/myapp/view/App.view.xml":'<mvc:View controllerName="com.myapp.controller.App"\n    xmlns:html="http://www.w3.org/1999/xhtml"\n    xmlns:mvc="sap.ui.core.mvc" displayBlock="true"\n    xmlns="sap.m"><App id="app"></App></mvc:View>\n',
	"com/myapp/view/View.view.xml":'<mvc:View controllerName="com.myapp.controller.View"\n    xmlns:mvc="sap.ui.core.mvc" displayBlock="true"\n    xmlns="sap.m"><Page id="page" title="{i18n>title}"><content /></Page></mvc:View>\n'
});
//# sourceMappingURL=Component-preload.js.map
