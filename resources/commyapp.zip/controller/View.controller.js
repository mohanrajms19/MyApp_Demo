sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("com.myapp.controller.View",{onInit:function(){}})});
//# sourceMappingURL=View.controller.js.map